package pzm;

import java.io.Serializable;

public class User implements Serializable{
	String username;
	int level;
	int score;
	public  User(String uname,int lvl,int scr){
		username = uname;
		level = lvl;
		score = scr;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	@Override
	public String toString() {
		return "User [username=" + username + ", level=" + level + ", score=" + score + "]";
	}
}

