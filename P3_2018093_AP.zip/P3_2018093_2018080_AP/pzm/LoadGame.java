package pzm;

import java.io.IOException;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoadGame extends Application{
	
	static Stage initStage = new Stage();
	@FXML
	private TextField takename;
		public void start(Stage primaryStage) throws Exception {
			Parent root = FXMLLoader.load(getClass().getResource("loadgame.fxml"));
			primaryStage.setTitle("LOAD GAME");
			Scene scene = new Scene(root,550,300); 
			scene.getStylesheets().add(getClass().getResource("welcome2.css").toExternalForm());
			primaryStage.setScene(scene);
			initStage = primaryStage;
			primaryStage.show();
		}
		public void gotogame() throws ClassNotFoundException, IOException{
			try{
			String savedgame = takename.getText();
			Serializedeserialize.filename = savedgame;
			Serializedeserialize.deserialize();
			Game game = Serializedeserialize.getGame();	
			resumeScreen pgame = new resumeScreen(game);
			try{
				pgame.start(pgame.getInitiateStage());
			}catch(Exception e){ }
			initStage.close();
			takename.setText("");
			}catch(Exception e){
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ALERT!");
				alert.setHeaderText("Wrong Input...");
				alert.showAndWait();
			}
		}
		public void listofsavedgames(){
			String names = "";
			for(String s : Screen1.filename){
				names = names + s+"\n";
			}
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("SAVED GAMES!");
			alert.setHeaderText(names);
			alert.showAndWait();
		}
		@FXML
	    void exit(ActionEvent event) {
			initStage.close();
		}
		public Stage getInitiateStage(){
			return initStage;
		}
	public static void main(String[] args) {
		launch(args);
	}

}
