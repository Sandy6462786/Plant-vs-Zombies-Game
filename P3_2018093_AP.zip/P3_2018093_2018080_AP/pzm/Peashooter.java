package pzm;

import java.util.Random;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

public class Peashooter extends Plant{
	private int shoot_count2 = 0;
    private int shoot_count3 = 5000;
    private boolean hasbuy = true;
    Random rand = new Random();
    
    public Peashooter(int row, int column, AnchorPane root, Player player){
        this.player = player;
        this.row = row;
        this.column = column;
        this.plant = new Image("file:C:/Users/Sandeep/Desktop/IMAGES/plants/peashooter.gif");
        this.plantView = new  ImageView(plant);
        s.getChildren().add(plantView);
        this.root = root;
        root.getChildren().add(s);
        s.setTranslateY((int) (135+(row-1)*110+55)-40);
        s.setTranslateX((int) (60+(column-1)*80+40)-40);
        this.imageX = 60+(column-1)*80+40-40;
        this.imageY = 135+(row-1)*110+55-40;
    }

    public void removeImage(){
        this.s.getChildren().remove(this.plantView);
        this.root.getChildren().remove(this.s);
    }
    public void setPosition(int row, int column){
        this.row = row;
        this.column = column;
    }
    public void setSize(double width, double height) {
        this.plantView.setFitWidth(width);
        this.plantView.setFitHeight(height);
    }

    public int getRow(){
        return this.row;
    }

    public int getColumn(){
        return this.column;
    }

    public int getHealth(){
        return this.health;
    }
    public void setHealth(int health){
        this.health = health;
    }
    public int getPower(){
        return power;
    }
    public void setPower(int power){
        this.power = power;
    }
    public int getPrice(){
        return 100;
    }
    public String getName(){
        return "peashooter";
    }
    public void sethasbuy(boolean bool){
    	hasbuy = bool;
    }
    public boolean gethasbuy(){
    	return hasbuy;
    }
    public void setImagePosition(double x, double y){
        this.imageX = x;
        this.imageY = y;
        s.setTranslateY(this.imageY);
        s.setTranslateX(this.imageX);
    }

	@Override
	public void step(){
        if (shoot_count == 2000){
            Pea pea = new Pea (this.row, this.column, this.root,this.player);
            this.player.addPea(pea);
            shoot_count = 0;
        } else {
            shoot_count ++;
        }
	}
	public void step1(){
		 if (shoot_count2 == 10000){
	            int q = 0;
	            for(Plant plant : player.getPlants()){
	            	if(plant.getName().equals("star")){
	            		GenerateSunflower gs1 = (GenerateSunflower)plant;
	            		if(gs1.isHasStar()){
	            			q = 1;
	            		}
	            	}
	            }
	            if(q==0){
	            	GenerateSunflower gs = new GenerateSunflower(rand.nextInt(3) -3, rand.nextInt(6)  + 1,this.root, this.player);
	            	gs.setHasStar(true);
	            	this.player.addPlants(gs);
	            }
	            shoot_count2 = 0;
	        } else {
	            shoot_count2 ++;
	        }
	}
	public void setshoot_count3tozero(){
		shoot_count3 = 0;
	}
	public void step3(){
        if (shoot_count3 == 5000){
            hasbuy = true;
        } else {
            shoot_count3 ++;
        }
	}
}
