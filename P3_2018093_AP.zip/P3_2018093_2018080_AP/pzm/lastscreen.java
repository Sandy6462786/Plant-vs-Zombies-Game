package pzm;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class lastscreen extends Application{
	static Stage initStage = new Stage();
	static String strng = "";
	@Override
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("lastscreen.fxml"));
		primaryStage.setTitle("PLANT VS ZOMBIES");
		Scene scene = new Scene(root); 
		scene.getStylesheets().add(getClass().getResource("welcome.css").toExternalForm());
		primaryStage.setScene(scene);
		initStage = primaryStage;
		
		Text text = new Text(strng);
		text.setX(40);
		text.setY(320);
		text.setId("fancytext");
        root.getChildren().add(text);
		
		primaryStage.show();
	}
	public Stage getInitiateStage(){
		return initStage;
	}
	@FXML
    void exit(ActionEvent event) {
		System.exit(0);
	}
	public static void main(String[] args) {
		launch(args);
	}
}
