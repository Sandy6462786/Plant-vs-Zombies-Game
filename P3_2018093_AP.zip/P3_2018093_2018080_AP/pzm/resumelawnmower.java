package pzm;

import java.io.Serializable;

public class resumelawnmower implements Serializable{
	private int row;
    private int column;
    private boolean lawnmowermoved = false;
	public int getRow() {
		return row;
	}
	public void setRow(int row) {
		this.row = row;
	}
	public int getColumn() {
		return column;
	}
	public void setColumn(int column) {
		this.column = column;
	}
	public boolean isLawnmowermoved() {
		return lawnmowermoved;
	}
	public void setLawnmowermoved(boolean lawnmowermoved) {
		this.lawnmowermoved = lawnmowermoved;
	}
}
