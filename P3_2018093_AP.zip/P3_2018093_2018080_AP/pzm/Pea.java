package pzm;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

public class Pea extends Plant{

	private double velocityX = 0.2;
	
	public Pea(int row, int column, AnchorPane root, Player player) {
        this.player = player;
        this.row = row;
        this.column = column;
        this.plant = new Image("file:C:/Users/Sandeep/Desktop/IMAGES/pea.png");
        this.plantView = new  ImageView(plant);
        s.getChildren().add(plantView);
        this.root = root;
        root.getChildren().add(s);
        s.setTranslateY((int) (135+(row-1)*110+55)-40);
        s.setTranslateX((int) (60+(column-1)*80+40)+40);
        this.imageX = 60+(column-1)*80+40+40;
        this.imageY = 135+(row-1)*110+55-40;
    }


    public void setPosition(double row, double column){
        this.row = (int) row;
        this.column = (int) column;
    }

    public void removeImage(){
        this.s.getChildren().remove(this.plantView);
        this.root.getChildren().remove(this.s);
    }

    public int getRow(){
        return (int)this.row;
    }

    public int getColumn(){
        int zombieCol = 0;
        if (getImagePositionX() >= 60 && getImagePositionX() <= 140) {
            zombieCol = 1;
        } else if (getImagePositionX() <= 211) {
            zombieCol = 2;
        } else if (getImagePositionX() <= 300) {
            zombieCol = 3;
        } else if (getImagePositionX() <= 380) {
            zombieCol = 4;
        } else if (getImagePositionX() <= 460) {
            zombieCol = 5;
        } else if (getImagePositionX() <= 540) {
            zombieCol = 6;
        } else if (getImagePositionX() <= 620) {
            zombieCol = 7;
        } else if (getImagePositionX() <= 700) {
            zombieCol = 8;
        } else if (getImagePositionX() <= 780) {
            zombieCol = 9;
        }
        else if(getImagePositionX()>=950){
        	zombieCol = 10;
        }
        return zombieCol;
    }

    public void step() {
        double imageX = getImagePositionX()+velocityX;
        setImagePosition(imageX, imageY);
        s.setTranslateY(this.imageY);
        s.setTranslateX(imageX);
    }

    public void setImagePosition(double x, double y){
        this.imageX = x;
        this.imageY = y;
    }

    public double getImagePositionX(){
        return this.imageX;
    }


	@Override
	public int getPrice() {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void setPosition(int x, int y) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public int getHealth() {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public void setHealth(int health) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public int getPower() {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public void setPower(int power) {
		// TODO Auto-generated method stub
		
	}
}
