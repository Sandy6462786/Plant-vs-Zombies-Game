package pzm;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public abstract class Zombie extends Character{
	
	protected Image zombie;
	protected int realcolumn;
	protected ImageView zombieView;
	protected double speed = -0.05;
    
    public abstract double getImagePositionX();
    
    public abstract double getSpeed();

    public abstract void setSpeed(double speed);

    public abstract void setColumn (int column);
    
    public abstract int getRealcolumn ();
}
