package pzm;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

public class CherryBomb extends Plant{

    private int shoot_count3 = 5000;
    private boolean hasbuy = true;
    private int shoot_count2 = 0;
    private boolean isDie = false;
 	
 	public CherryBomb(int row, int column, AnchorPane root){
         this.row = row;
         this.column = column;
         this.plant = new Image("file:C:/Users/Sandeep/Desktop/IMAGES/cherrybomb.png");
         this.plantView = new  ImageView(plant);
         s.getChildren().add(plantView);
         this.root = root;
         root.getChildren().add(s);
         s.setTranslateY((int) (135+(row-1)*110+55)-40);
         s.setTranslateX((int) (60+(column-1)*80+40)-40);
         this.imageX = 60+(column-1)*80+40-40;
         this.imageY = 135+(row-1)*110+55-40;
     }
     public int getRow(){
         return this.row;
     }

     public int getColumn(){
         return this.column;
     }


     public void removeImage(){
         this.s.getChildren().remove(this.plantView);
         this.root.getChildren().remove(this.s);
     }
     public void setPosition(int row, int column){
         this.row = row;
         this.column = column;
     }

     public void setSize(double width, double height) {
         this.plantView.setFitWidth(width);
         this.plantView.setFitHeight(height);
     }

     public int getHealth(){
         return health;
     }

     public void setHealth(int health){
         this.health = health;
     }

     public int getPower(){
         return power;
     }

     public void setPower(int power){
         this.power = power;
     }

     public int getPrice(){
         return 150;
     }

     public void setPrice(int price){
         this.price = price;
     }

     public String getName(){
         return "cherrybomb";
     }
     public void sethasbuy(boolean bool){
     	hasbuy = bool;
     }
     public boolean gethasbuy(){
     	return hasbuy;
     }
     public void setisDie(boolean bool){
      	isDie = bool;
      }
      public boolean getisDie(){
      	return isDie;
      }
 	@Override
 	public void step() {
 		// TODO Auto-generated method stub
 		
 	}
	public void setshoot_count2tozero(){
		shoot_count2 = 0;
	}
	public void step2(){
        if (shoot_count2 == 1000){
            isDie = true;
        } else {
            shoot_count2 ++;
        }
	}
 	public void setshoot_count3tozero(){
		shoot_count3 = 0;
	}
	public void step3(){
        if (shoot_count3 == 5000){
            hasbuy = true;
        } else {
            shoot_count3 ++;
        }
	}
}
