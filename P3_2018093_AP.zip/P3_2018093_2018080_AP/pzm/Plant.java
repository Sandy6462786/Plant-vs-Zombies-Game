package pzm;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public abstract class Plant extends Character{
	
	protected int price = 100;
	protected Image plant;
	protected  ImageView plantView;
	protected int shoot_count = 1900;
    
    public abstract int getPrice();
    public abstract String getName();
}
