package pzm;

import java.util.ArrayList;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ChooseLevel extends Application{
	
	static Stage initStage = new Stage();
	@FXML
	private TextField takename;
		public void start(Stage primaryStage) throws Exception {
			Parent root = FXMLLoader.load(getClass().getResource("chooselevel.fxml"));
			primaryStage.setTitle("CHOOSE LEVEL");
			Scene scene = new Scene(root,550,300); 
			scene.getStylesheets().add(getClass().getResource("welcome2.css").toExternalForm());
			primaryStage.setScene(scene);
			initStage = primaryStage;
			primaryStage.show();
		}
		public void gotolevel(){
			try{
				int level = Screen2.level;
				int level1 = Integer.parseInt(takename.getText());
				int q = 0;
				for(int i=1;i<=level;i++){
					if(level==level1){
						q = 1;
					}
				}
				if(q==0){
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("ALERT!");
					alert.setHeaderText("Level is not unlocked...");
					alert.showAndWait();
				}
				if(q==1){
					Screen2.level = level1;
					Screen3 pgame = new Screen3();
					try{
						pgame.start(pgame.getInitiateStage());
					}catch(Exception e){ }
					initStage.close();
					Screen1.initStage.close();
				}
			} catch(Exception e){
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ALERT!");
				alert.setHeaderText("Wrong Input...");
				alert.showAndWait();
			}
			
			takename.setText("");
		}
		public void checklevel(){
			int level = Screen2.level;
			String levels = "";
			for(int i=1;i<=level;i++){
				levels = levels + "  "+i;
			}
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("UNLOCKED LEVELS!");
			alert.setHeaderText(levels);
			alert.showAndWait();
		}
		@FXML
	    void exit(ActionEvent event) {
			initStage.close();
		}
		public Stage getInitiateStage(){
			return initStage;
		}
	public static void main(String[] args) {
		launch(args);
	}

}
