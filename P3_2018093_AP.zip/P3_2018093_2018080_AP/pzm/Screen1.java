package pzm;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class Screen1 extends Application{
	static Stage initStage;
	static String username;
	static ArrayList<String> users = new ArrayList<>();
	static ArrayList<String> filename = new ArrayList<>();
	
		public void start(Stage primaryStage) throws Exception {
			Parent root = FXMLLoader.load(getClass().getResource("Welcome.fxml"));
			primaryStage.setTitle("PLANT VS ZOMBIES");
			Scene scene = new Scene(root); 
			scene.getStylesheets().add(getClass().getResource("welcome.css").toExternalForm());
			primaryStage.setScene(scene);
			initStage = primaryStage;
			primaryStage.show();
		}
		public void createuser(){
			CreateUser pgame = new CreateUser();
			try{
				pgame.start(pgame.getInitiateStage());
			}catch(Exception e){ }
		}
		@FXML
	    void playgame(ActionEvent event) throws Exception {
				Login pgame = new Login();
				try{
					pgame.start(pgame.getInitiateStage());
				}catch(Exception e){ }
		}
		public void loadgame(){
			File dir = new File("C:/Users/Sandeep/workspace/PlantZombiesMain");
			for(File file : dir.listFiles()){
				if(file.getName().endsWith(".txt")){
					filename.add(file.getName());
				}
			}
			LoadGame pgame = new LoadGame();
			try{
				pgame.start(pgame.getInitiateStage());
			}catch(Exception e){ }
			initStage.close();
		}
		@FXML
	    void exit(ActionEvent event) {
			initStage.close();
		}
		public void showscore() throws ClassNotFoundException, IOException{
			Serializedeserialize.deserializescoreboard();
			ArrayList<User> array = Serializedeserialize.getscoreboard();
			String names = "";
			for(User s : array){
				names = names + s+"\n";
			}
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("SCORE BOARD!");
			alert.setHeaderText(names);
			alert.showAndWait();
		}
		public void chooselevel(){
			ChooseLevel pgame = new ChooseLevel();
			try{
				pgame.start(pgame.getInitiateStage());
			}catch(Exception e){ }
		}
	public static void main(String[] args) {
		launch(args);
	}
}
