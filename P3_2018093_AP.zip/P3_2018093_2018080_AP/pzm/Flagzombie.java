package pzm;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

public class Flagzombie extends Zombie {
	
	private int health = 800;
	 private int power = 8;

	public Flagzombie(int row, int column, AnchorPane root) {
       this.row = row;
       this.column = column;
       this.realcolumn = column;
       this.zombie = new Image("file:C:/Users/Sandeep/Desktop/IMAGES/zombies/z33.gif");
       this.zombieView = new ImageView(zombie);
       s.getChildren().add(zombieView);
       root.getChildren().add(s);
       s.setTranslateY((int) (135 + (row - 1) * 110 + 55) - 70 + 1);
       s.setTranslateX((int) (60 + (column - 1) * 80 + 40) - 40);
       this.imageX = 60 + (column - 1) * 80 + 40 + 40;
       this.imageY = 135 + (row - 1) * 110 + 55 - 70;
   }

   public int getRealcolumn() {
		return realcolumn;
	}

	public void setRealcolumn(int realcolumn) {
		this.realcolumn = realcolumn;
	}
   public void removeImage() {
       this.s.getChildren().remove(this.zombieView);
       this.root.getChildren().remove(this.s);
   }

   public void setImagePosition(double x, double y) {
       this.imageX = x;
       this.imageY = y;
   }

   public double getImagePositionX() {
       return this.imageX;
   }

   public int getRow() {
       return this.row;
   }

   public int getColumn() {
       int zombieCol = 13;
       if (getImagePositionX() >= 60 && getImagePositionX() <= 140) {
           zombieCol = 1;
       } else if (getImagePositionX() <= 211) {
           zombieCol = 2;
       } else if (getImagePositionX() <= 300) {
           zombieCol = 3;
       } else if (getImagePositionX() <= 380) {
           zombieCol = 4;
       } else if (getImagePositionX() <= 460) {
           zombieCol = 5;
       } else if (getImagePositionX() <= 540) {
           zombieCol = 6;
       } else if (getImagePositionX() <= 620) {
           zombieCol = 7;
       } else if (getImagePositionX() <= 700) {
           zombieCol = 8;
       } else if (getImagePositionX() <= 780) {
           zombieCol = 9;
       }else if(getImagePositionX() <=860){
       	zombieCol = 10;
       }else if(getImagePositionX() <=920){
       	zombieCol = 11;
       }else if(getImagePositionX() <=980){
       	zombieCol = 12;
       }
       return zombieCol;
   }

   public void setColumn(int column) {
       this.column = column;
   }

   public int getHealth() {
       return health;
   }

   public void setHealth(int health) {
       this.health = health;

   }

   public int getPower() {
       return power;
   }

   public void setSpeed(double speed) {
       this.speed = speed;

   }

   public void step() {
       double imageX = getImagePositionX() + this.speed;
       setImagePosition(imageX, imageY);
       s.setTranslateY(this.imageY);
       s.setTranslateX(imageX);
   }

	@Override
	public void setPosition(int x, int y) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setPower(int power) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double getSpeed() {
		return -0.05;
	}
	
}
