package pzm;

import java.util.ArrayList;

import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class Player {
	
	private int sun = 200;
    private ArrayList<Plant> listPlants = new ArrayList<>();
    private ArrayList<Pea> listPeas = new ArrayList<>();
    private ArrayList<Lawnmower> lawnmower = new ArrayList<>();
    private static AnchorPane root;
   static  Label time = new Label(GameController.ttime);
    Label sunLabel;
    Label sunOriginal;
    public Player(AnchorPane root,Label priceLabel){
    	this.sunOriginal = priceLabel;
        this.root = root;
    }

    public int getSun(){
        return this.sun;
    }

    public ArrayList<Plant> getPlants(){
        return listPlants;
    }

    public ArrayList<Pea> getPeas(){
        return listPeas;
    }
    
    public ArrayList<Lawnmower> getlawnmowers(){
    	return lawnmower;
    }
    public void setlistplants(ArrayList<Plant> splant){
    	this.listPlants = splant;
    }
    public void setlistlawnmowers(ArrayList<Lawnmower> slawnmower){
    	this.lawnmower = slawnmower;
    }

    public void setSun(int sun){
        this.sun = sun;
        this.root.getChildren().remove(this.sunLabel);
        this.root.getChildren().remove(this.sunOriginal);
        Label sunL = new Label(Integer.toString(getSun()));
        this.sunLabel = sunL;
        sunL.setFont(new Font(25));
        sunL.setTextFill(Color.BLUE);
        this.root.getChildren().add(sunLabel);
        sunL.setTranslateX(70);
        sunL.setTranslateY(75);
    }
    
    public static void settime(){
    	root.getChildren().remove(time);
    	Label times = new Label(GameController.ttime);
    	time = times;
	     times.setFont(new Font(25));
	     times.setTextFill(Color.BLACK);
	     root.getChildren().add(times);
	     times.setTranslateX(700);
	     times.setTranslateY(5);
    }

    public void addPlants(Plant plant){
        listPlants.add(plant);
    }

    public void addPea(Pea pea){
        listPeas.add(pea);

    }
    
    public void addlandowner(Lawnmower lawn){
        lawnmower.add(lawn);
    }
    public Label getsun(){
    	return sunLabel;
    }
}
