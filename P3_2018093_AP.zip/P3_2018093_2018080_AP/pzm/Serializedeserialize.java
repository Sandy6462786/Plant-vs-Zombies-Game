package pzm;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class Serializedeserialize{
	private  static Game game = null;
	static ArrayList<User> users = new ArrayList<>();
	static String filename = null;
	public Serializedeserialize(Game game){
		this.game = game;
	}
	public static Game getGame() {
		return game;
	}
	public static ArrayList<User> getscoreboard(){
		return users;
	}
	public static void setGame(Game g) {
		game = g;
	}
	public static void serialize() throws IOException{
		ObjectOutputStream out = null;
		try{
			out = new ObjectOutputStream(new FileOutputStream(filename));
			out.writeObject(game);
		}
		finally{
			out.close();
		}
	}
	public static void serializescore() throws IOException, ClassNotFoundException{
		users.add(new User(Screen1.username, Screen2.level, Screen2.score));
		ObjectOutputStream out = null;
		try{
			out = new ObjectOutputStream(new FileOutputStream("score1.txt"));
			out.writeObject(users);
		}
		finally{
			out.close();
		}
	}
	public static void deserialize() throws IOException,ClassNotFoundException{
		ObjectInputStream in = null;
		try{
			in = new ObjectInputStream(new FileInputStream(filename));
			game = (Game)in.readObject();
		}
		finally{
			if(in!=null){
				in.close();
			}
		}
	}
	public static void deserializescoreboard() throws IOException,ClassNotFoundException{
		ObjectInputStream in = null;
		try{
			in = new ObjectInputStream(new FileInputStream("score1.txt"));
			users = (ArrayList<User>)in.readObject();
		}
		finally{
			if(in!=null){
				in.close();
			}
		}
	}
}
