package pzm;

import java.util.ArrayList;
import java.util.Random;

import javafx.scene.layout.AnchorPane;

public class Enemy {

	private int difficulty;
    private ArrayList<Zombie> zombies = new ArrayList<>();
    AnchorPane root;
    Random rand = new Random();

    public Enemy(AnchorPane root, int difficulty){
        this.root = root;
        this.difficulty = difficulty;
        if(difficulty!=0){
        	zombies = generateZombies(difficulty);
        }
    }

    public ArrayList<Zombie> generateZombies(int difficulty){
        int norm1 = (int) Math.round(difficulty * 0.7);
//        System.out.println(norm);
        int strong = difficulty - norm1;
        int norm2 = norm1;
        int norm3 = norm1;
        for (int i = 0; i < difficulty; i++){
            for (int j = 0; j < norm1; j++){
                Flagzombie flagzombie =  new Flagzombie(rand.nextInt(5)  + 1, rand.nextInt(20)  + 9, root);
                zombies.add(flagzombie);
            }
//            for (int j = 0; j < norm2; j++){
//                Bucketzombie bucketzombie =  new Bucketzombie(rand.nextInt(5)  + 1, rand.nextInt(5)  + 9, root);
//                zombies.add(bucketzombie);
//            }
            for (int j = 0; j < norm3; j++){
                NormalZombie normalZombie =  new NormalZombie(rand.nextInt(5)  + 1, rand.nextInt(20)  + 9, root);
                zombies.add(normalZombie);
            }
            for (int k = 0; k < strong; k++){
                HeadpieceZombie strongZombie = new HeadpieceZombie(rand.nextInt(5)  + 1,rand.nextInt(20)  + 9, root);
                zombies.add(strongZombie);
            }
        }
        return zombies;
    }

    public ArrayList<Zombie> getZombies(){
        return zombies;
    }
    public void setlistzombies(ArrayList<Zombie> szombies){
    	this.zombies = szombies;
    }
    public int getdifficulty(){
    	return difficulty;
    }
}
