package pzm;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;

public class GenerateSunflower extends Plant {
	private double velocityY = 0.05;
    private String name = "";
    private Image star;
    private ImageView starView;
    private boolean hasStar = false;
    private StackPane s2 = new StackPane();

    public GenerateSunflower(int row, int column, AnchorPane root, Player player){
        this.star= new Image("file:C:/Users/Sandeep/Desktop/IMAGES/sun.png");
        this.starView = new ImageView(star);
        this.s2.getChildren().add(starView);
        this.player = player;
        this.row = row;
        this.column = column;
        this.root = root;
        root.getChildren().add(s2);
        this.imageX = 60+(column-1)*80+40-40;
        this.imageY = 135+(row-1)*110+55-40;
    }

    public void removeImage(){
        this.s2.getChildren().remove(this.starView);
        this.root.getChildren().remove(this.s2);
    }

    public void removeStar(){
        this.s2.getChildren().remove(this.starView);
        this.root.getChildren().remove(this.s2);
    }

    public int getRow(){
        return this.row;
    }

    public int getColumn(){
        return this.column;
    }

    public void setPosition(int row, int column){
        this.row = row;
        this.column = column;
    }

    public int getHealth(){
        return health;
    }

    public void setHealth(int health){
        this.health = health;
    }

    public int getPower(){
        return power;
    }

    public void setPower(int power){
        this.power = power;
    }

    public int getPrice(){
        return price;
    }

    public void setPrice(int price){
        this.price = price;
    }

    public String getName(){
        return "star";
    }
    
    public double getImagePositionY(){
    	return imageY;
    }
    public double getImagePositionX(){
    	return imageX;
    }
    
    public void setImagePosition(double x, double y){
        this.imageX = x;
        this.imageY = y;
    }
    
	@Override
    public void step(){
		if(imageY<500){
			double imageY = getImagePositionY()+velocityY;
			setImagePosition(imageX, imageY);
			s2.setTranslateY(imageY);
			s2.setTranslateX(imageX);
		}
    }
	
	 public boolean isHasStar(){
	        return hasStar;
	    }
	 public void setHasStar(boolean bool){
	        hasStar = bool;
	    }
}


