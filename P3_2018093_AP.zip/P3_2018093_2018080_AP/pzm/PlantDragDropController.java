package pzm;

import javafx.event.EventHandler;
import javafx.scene.input.DragEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;

public class PlantDragDropController implements EventHandler<DragEvent> {
    AnchorPane root;
    Player player;
    //private Sun sun;
    Peashooter peashooter = null;
    Sunflower sunflower = null;
    Wallnut wallnut = null;
    CherryBomb cherrybomb = null;
    Redchilli redchilli = null;

    public PlantDragDropController(AnchorPane root, Player player){
        this.root = root;
        this.player = player;
    }
    @Override
    public void handle(DragEvent event) {
        int row=1;
        int column=(int)event.getX()-40;
        String type = event.getDragboard().getString();
        StackPane s1 = new StackPane();

        if (event.getX()>=60 && event.getX() <= 780) {
            if (event.getY() >= 135 && event.getY() <= 685) {
                if (event.getY() >= 135 && event.getY() <= 245){
                    row=1;
                } else if (event.getY() < 355) {
                    row=2;
                } else if (event.getY() < 465) {
                    row=3;
                } else if ( event.getY() < 575){
                    row=4;
                } else if (event.getY() < 685) {
                    row=5;
                }

                if (event.getX() >= 60 && event.getX() <= 140){
                    column = 1;
                } else if (event.getX()<=211) {
                    column = 2;
                } else if (event.getX()<=300) {
                    column = 3;
                }else if (event.getX()<=380){
                    column = 4;
                } else if (event.getX()<=460) {
                    column = 5;
                } else if (event.getX()<=540) {
                    column = 6;
                } else if (event.getX()<=620) {
                    column = 7;
                } else if (event.getX()<=700) {
                    column = 8;
                }else if (event.getX()<=780) {
                    column = 9;
                }

                boolean add = true;

                for (Plant plant : player.getPlants()) {
                    if(plant.getName().equals("peashooter")){
                    	peashooter = (Peashooter)plant;
                    }
                    if(plant.getName().equals("sunflower")){
                    	sunflower = (Sunflower)plant;
                    }
                    if(plant.getName().equals("wallnut")){
                    	wallnut = (Wallnut) plant;
                    }
                    if(plant.getName().equals("cherrybomb")){
                    	cherrybomb = (CherryBomb) plant;
                    }
                    if(plant.getName().equals("redchilli")){
                    	redchilli = (Redchilli) plant;
                    }
                    if (plant.getRow() == row && plant.getColumn() == column) {
                        add = false;
                    }
                }

                if (add) {
                    switch (type) {
                        case "peashooter":
                            if (this.player.getSun() >= 100){
                            	if(peashooter.gethasbuy()){
                            		Peashooter peashooter = new Peashooter(row, column,root, player);
                            		player.addPlants(peashooter);
                            		player.setSun(player.getSun() - peashooter.getPrice());
                            		peashooter.sethasbuy(false);
                            		peashooter.setshoot_count3tozero();
                            	}
                            }
                            break;
                        case "wallnut":
                            if (this.player.getSun() >= 50) {
                            	if(wallnut.gethasbuy()){
                            		Wallnut wallnut = new Wallnut(row, column,root);
                            		player.addPlants(wallnut);
                            		player.setSun(player.getSun() - wallnut.getPrice());
                            		wallnut.sethasbuy(false);
                            		wallnut.setshoot_count3tozero();
                            	}
                            }
                            break;
                        case "redchilli":
                            if (this.player.getSun() >= 50) {
                            	if(redchilli.gethasbuy()){
                            		Redchilli redchilli1 = new Redchilli(row, column,root);
                            		player.addPlants(redchilli1);
                            		player.setSun(player.getSun() - redchilli1.getPrice());
                            		redchilli.sethasbuy(false);
                            		redchilli.setshoot_count3tozero();
                            		redchilli.setshoot_count2tozero();
                            	}
                            }
                            break;
                        case "cherrybomb":
                            if (this.player.getSun() >= 50) {
                            	if(cherrybomb.gethasbuy()){
                            		CherryBomb cherrybomb1 = new CherryBomb(row, column, root);
                            		player.addPlants(cherrybomb1);
                            		player.setSun(player.getSun() - cherrybomb1.getPrice());
                            		cherrybomb.sethasbuy(false);
                            		cherrybomb.setshoot_count3tozero();
                            		cherrybomb.setshoot_count2tozero();
                            	}
                            }
                            break;
                        case "sunflower":
                            if (this.player.getSun() >= 50) {
                            	if(sunflower.gethasbuy()){
                                Sunflower sunflower = new Sunflower(row, column,root,player);
                                player.addPlants(sunflower);
                                player.setSun(player.getSun() - sunflower.getPrice());
                                sunflower.sethasbuy(false);
                        		sunflower.setshoot_count3tozero();
                            }
                            }
                            break;
                    }
                }
            }
        }
    }

}


