package pzm;

import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.*;
import java.util.logging.Level;

public class GameController implements EventHandler<KeyEvent> {
    final private double FRAMES_PER_SECOND = 60.0;
    private int difficulty;
    private Player player;
    private Enemy enemy;
    private boolean playerWin = false;
    private boolean zombieWin = false;
    private Stage stage;
    private Timer timer;
    private Game g = new Game();
    static int time = 1;
    static int timesec = 0;
    static int timemin = 0;
    static int increment = 0;
    static String ttime = "";

    public GameController(int difficulty, Player player, Enemy enemy, Stage initStage) {
        this.difficulty = difficulty;
        this.player = player;
        this.enemy = enemy;
        this.stage = initStage;
    }

    public void initialize() {
        this.startTimer();
    }

    private void startTimer() {
        this.timer = new java.util.Timer();
        TimerTask timerTask = new TimerTask() {
            public void run() {
                Platform.runLater(new Runnable() {
                    public void run() {
                    	if(time==1){
                    		try {
								updateAnimation();
							} catch (ClassNotFoundException e) {
								// TODO Auto-generated catch block
							} catch (IOException e) {
								// TODO Auto-generated catch block
							}
                    	}else{ }
                    	increment++;
                    	if(increment==500){
                    		timesec++;
                    		increment = 0;
                    		if(timesec==59){
                    			timesec = 0;
                    			timemin++;
                    		}
                    		ttime = timemin+" min "+timesec+" sec";
                    		Player.settime();
                    	}
                    }
                });
            }
        };
        long frameTimeInMilliseconds = (long)(time);
        this.timer.schedule(timerTask, 0, frameTimeInMilliseconds);
    }

    public Player getPlayer(){
        return player;
    }

    private void updateAnimation() throws ClassNotFoundException, IOException {
            ArrayList<Plant> listOfPlants = checkPlants();
            ArrayList<Zombie> listOfZombies = checkZombies();
            ArrayList<Pea> listOfPeas = checkPeas();
            runFight(listOfPlants, listOfZombies, listOfPeas);
            
             ArrayList<resumeplants> rplants = new ArrayList<>();
             ArrayList<resumezombie> rzombies = new ArrayList<>();
             ArrayList<resumelawnmower> resumelawnmowers = new ArrayList<>();
             for(Plant plant : listOfPlants){
            	 resumeplants replant = new resumeplants();
            	 replant.setColumn(plant.getColumn());
            	 replant.setHealth(plant.getHealth());
            	 replant.setPower(plant.getPower());
            	 replant.setPrice(plant.getPrice());
            	 replant.setRow(plant.getRow());
            	 replant.setName(plant.getName());
            	 rplants.add(replant);
             }
             for(Zombie zombie : listOfZombies){
            	 resumezombie rezombie = new resumezombie();
            	 rezombie.setColumn(zombie.getColumn());
            	 rezombie.setHealth(zombie.getHealth());
            	 rezombie.setPower(zombie.getPower());
            	 rezombie.setRow(zombie.getRow());
            	 rezombie.setRealcolumn(zombie.getRealcolumn());
            	 rzombies.add(rezombie);
             }
             for(Lawnmower lawnmower : player.getlawnmowers()){
            	 resumelawnmower relawnmower = new resumelawnmower();
            	 relawnmower.setColumn(lawnmower.getColumn());
            	 relawnmower.setLawnmowermoved(lawnmower.gethaslawnmower());
            	 relawnmower.setRow(lawnmower.getRow());
            	 resumelawnmowers.add(relawnmower);
             }
             g.setLevel(Screen2.level);
             g.setSun(player.getSun());
             g.setListPlants(rplants);
             g.setListzombies(rzombies);
             g.setListlawnmower(resumelawnmowers);
            Screen3.game = g;
            
            for (Pea pea: listOfPeas) {
                pea.step();
            }
          
            for (Plant plant : listOfPlants) {
            	if(plant.getName().equals("peashooter")){
            		Peashooter peashooter = (Peashooter)plant;
            		peashooter.step1();
            		peashooter.step3();
            	  for (Zombie zombie : enemy.getZombies()) {
            		  if(plant.getRow()==zombie.getRow() && zombie.getColumn()<=10){
            			  plant.step();
            		  }
            	  }
            	} if(plant.getName().equals("sunflower")){
            		Sunflower sunflower = (Sunflower)plant;
            		sunflower.step3();
            		sunflower.step();
            	} if(plant.getName().equals("wallnut")){
            		Wallnut wallnut = (Wallnut) plant;
            		wallnut.step3();
            		wallnut.step();
            	} if(plant.getName().equals("cherrybomb")){
            		CherryBomb cherrybomb = (CherryBomb) plant;
            		cherrybomb.step3();
            		cherrybomb.step2();
            		cherrybomb.step();
            	}
            	if(plant.getName().equals("redchilli")){
            		Redchilli redchilli = (Redchilli) plant;
            		redchilli.step3();
            		redchilli.step2();
            		redchilli.step();
            	}
            		else if(!plant.getName().equals("peashooter")){
            		plant.step();
            	}
            }
           
            for (Zombie zombie : enemy.getZombies()) {
                zombie.step();
            }
            for(Lawnmower landmower : player.getlawnmowers()){
            	if(landmower.gethaslawnmower()){
            		landmower.step();
            	}
            }
        }



    private ArrayList<Plant> checkPlants(){
        ArrayList<Plant> listOfPlants = player.getPlants();
        return listOfPlants;
    }

    private ArrayList<Pea> checkPeas(){
        ArrayList<Pea> listOfPeas = player.getPeas();
        return listOfPeas;
    }

    private ArrayList<Zombie> checkZombies(){
        ArrayList<Zombie> listOfZombies = enemy.getZombies();
        return listOfZombies;
    }

    private void runFight(ArrayList<Plant> plants, ArrayList<Zombie> zombies, ArrayList<Pea> peas) throws ClassNotFoundException, IOException{
        boolean plantDie = false;
        for(Lawnmower landmower : player.getlawnmowers()){
        	if (landmower.getColumn() == 10) {
            	player.getlawnmowers().remove(landmower);
            	landmower.removeImage();
            }
        }
        ArrayList<Zombie> blockZombie = new  ArrayList<Zombie>();
        for (Iterator<Zombie> iterator2 = zombies.iterator(); iterator2.hasNext(); ) {
            Zombie zombie = iterator2.next();
            for(Lawnmower landmower : player.getlawnmowers()){
        		if((zombie.getImagePositionX()-landmower.getImagePositionX()<=0) && landmower.getRow()==zombie.getRow() && landmower.gethaslawnmower()){
        			enemy.getZombies().remove(zombie);
        			Screen2.score = Screen2.score+1;
                    zombie.removeImage();
                    iterator2.remove();
        		}
            }
            if (zombie.getImagePositionX()<220){
            	for(Lawnmower landmower : player.getlawnmowers()){
            		if(landmower.getRow()==zombie.getRow()){
            			if(!landmower.gethaslawnmower()){
            				landmower.sethaslawnmower(true);
            				enemy.getZombies().remove(zombie);
            				Screen2.score = Screen2.score+1;
                            zombie.removeImage();
                            iterator2.remove();
            			} }}}
            				if(zombie.getImagePositionX()<=150){
            				  this.zombieWin = true;
            			}
            for (Iterator<Plant> iterator = plants.iterator(); iterator.hasNext(); ) {
                Plant plant = iterator.next();
                int plantRow = plant.getRow();
                int plantColumn = plant.getColumn();
                int zombieRow = zombie.getRow();
                int zombieColumn = zombie.getColumn();

                if (plant.getName().equals("peashooter")) {
                    for (Iterator<Pea> iterator3 = peas.iterator(); iterator3.hasNext(); ) {
                        Pea pea = iterator3.next();
                        int peaRow = pea.getRow();
                        int peaX = (int) Math.round(pea.getImagePositionX());
                   
                        if (plantRow == peaRow && peaRow == zombieRow && peaX-(int)zombie.getImagePositionX()>=5) {
                            pea.removeImage();
                            int zombieHealth = zombie.getHealth();
                            int plantPower = plant.getPower();
                            zombie.setHealth(zombieHealth - plantPower);
                            iterator3.remove();
                            player.getPeas().remove(pea);
                            if (zombie.getHealth() <= 0) {
                            	enemy.getZombies().remove(zombie);
                            	Screen2.score = Screen2.score+1;
                                zombie.removeImage();
                                iterator2.remove();
                            }
                        }
                      
                        if (pea.getColumn()==10) {
                        	player.getPeas().remove(pea);
                        	pea.removeImage();
                            iterator3.remove();
                        }
                    }
                }
                
                if(plant.getName().equals("cherrybomb") && plantRow!=-2 && plantColumn!=-2){
                	if (-plant.imageX+(int)zombie.getImagePositionX()<100 && -plant.imageX+(int)zombie.getImagePositionX()>0 && plantRow == zombieRow){
                		enemy.getZombies().remove(zombie);
                		Screen2.score = Screen2.score+1;
                		zombie.removeImage();
                        iterator2.remove();
                	}
                	if (-plant.imageX+(int)zombie.getImagePositionX()<0 && -plant.imageX+(int)zombie.getImagePositionX()>-100 && plantRow == zombieRow){
                		enemy.getZombies().remove(zombie);
                		Screen2.score = Screen2.score+1;
                		zombie.removeImage();
                        iterator2.remove();
                	}
                	if (plant.imageY-(int)zombie.imageY>0 && plant.imageY-(int)zombie.imageY<120 && plantColumn == zombieColumn){
                		enemy.getZombies().remove(zombie);
                		Screen2.score = Screen2.score+1;
                		zombie.removeImage();
                        iterator2.remove();
                	}
                	if (plant.imageY-(int)zombie.imageY>-120 && plant.imageY-(int)zombie.imageY<0 && plantColumn == zombieColumn){
                		enemy.getZombies().remove(zombie);
                		Screen2.score = Screen2.score+1;
                		zombie.removeImage();
                        iterator2.remove();
                	}
                	CherryBomb cherrybomb = (CherryBomb) plant;
                	if(cherrybomb.getisDie()){
                		player.getPlants().remove(plant);
                    	plant.removeImage();
                    	iterator.remove();
                	}
                }
                
                if(plant.getName().equals("redchilli") && plantRow!=-2 && plantColumn!=-2){
                	if (-plant.imageX+(int)zombie.getImagePositionX()<5&& plantRow == zombieRow){
                		enemy.getZombies().remove(zombie);
                		Screen2.score = Screen2.score+1;
                		zombie.removeImage();
                        iterator2.remove();
                	}
                	if (-plant.imageX+(int)zombie.getImagePositionX()>5 && plantRow == zombieRow){
                		enemy.getZombies().remove(zombie);
                		Screen2.score = Screen2.score+1;
                		zombie.removeImage();
                        iterator2.remove();
                	}
                	Redchilli redchilli = (Redchilli) plant;
                	if(redchilli.getisDie()){
                		player.getPlants().remove(plant);
                    	plant.removeImage();
                    	iterator.remove();
                	}
                }
            
                if (plantRow == zombieRow && plantColumn == zombieColumn) {
                    zombie.setSpeed(0);
                    blockZombie.add(zombie);
                    int plantHealth = plant.getHealth();
                    int zombiePower = zombie.getPower();
                    plant.setHealth(plantHealth-zombiePower);
                    if (plant.getHealth() < 50) {
                        if (plant.getHealth() <= 0){
                            plantDie = true;
                        }
                        zombie.setSpeed(zombie.getSpeed());
                    }
                }
                if (plantDie == true){
                    plant.removeImage();
                    iterator.remove();
                }
                plantDie = false;
            }
            
        }
        
        if (enemy.getZombies().isEmpty()){
            this.playerWin = true;
        }
        checkIfEnd();
    }

    
    public void checkIfEnd() throws IOException, ClassNotFoundException{
        if (this.playerWin) {
        	if(Screen2.level==5){
        		lastscreen.strng = "You win";
        		Serializedeserialize.deserializescoreboard();
    			Serializedeserialize.serializescore();
        		 lastscreen pgame = new lastscreen();
     			try{
     				pgame.start(pgame.getInitiateStage());
     			}catch(Exception e){ }
                 try{
                     this.timer.cancel();
                     this.stage.close();
                 } catch (Exception e){  }
        	}
        	else{
            Screen4 pgame = new Screen4();
			try{
				pgame.start(pgame.getInitiateStage());
			}catch(Exception e){ }
            try {
                this.timer.cancel();
                this.stage.close();
            } catch (Exception e) {
            }
        }
        }
        if (this.zombieWin){
            lastscreen.strng = "You lose";
            Serializedeserialize.deserializescoreboard();
			Serializedeserialize.serializescore();
            lastscreen pgame = new lastscreen();
			try{
				pgame.start(pgame.getInitiateStage());
			}catch(Exception e){ }
            try{
                this.timer.cancel();
                this.stage.close();
            } catch (Exception e){
            }

        }
    }

    @Override
    public void handle(KeyEvent keyEvent) {

    }
}