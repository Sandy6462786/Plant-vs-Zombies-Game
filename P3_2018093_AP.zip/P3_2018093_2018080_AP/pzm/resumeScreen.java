package pzm;

import java.io.Serializable;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class resumeScreen extends Application{
	static Game game;
	static Stage initStage = new Stage();
	public resumeScreen(Game game) {
		this.game = game;
	}
	@Override
	public void start(Stage stage) throws Exception {
		AnchorPane root2 = FXMLLoader.load(getClass().getResource("FXML1.fxml"));
		Scene scene = new Scene(root2,1320,760);
		stage.setScene(scene);
		scene.getStylesheets().add(getClass().getResource("welcome.css").toExternalForm());

		Label sun = new Label(Integer.toString(game.getSun()));
		Player player = new Player(root2,sun);
		player.setSun(game.getSun());
		
		ArrayList<Plant> splant = new ArrayList<>();
		ArrayList<Zombie> szombie = new ArrayList<>();
		ArrayList<Lawnmower> slawnmowers = new ArrayList<>();
		for(resumeplants plant : game.getListPlants()){
			if(plant.getName().equals("peashooter")){
				Peashooter peashooter = new Peashooter(plant.getRow(), plant.getColumn(), root2, player);
				peashooter.setHealth(plant.getHealth());
				splant.add(peashooter);
			}
			if(plant.getName().equals("sunflower")){
				Sunflower sunflower = new Sunflower(plant.getRow(),plant.getColumn(), root2, player);
				sunflower.setHealth(plant.getHealth());
				splant.add(sunflower);
			}
			if(plant.getName().equals("wallnut")){
				Wallnut wallnut = new Wallnut(plant.getRow(),plant.getColumn(), root2);
				wallnut.setHealth(plant.getHealth());
				splant.add(wallnut);
			}
			if(plant.getName().equals("cherrybomb")){
				CherryBomb cherrybomb = new CherryBomb(plant.getRow(),plant.getColumn(), root2);
				cherrybomb.setHealth(plant.getHealth());
				splant.add(cherrybomb);
			}
			if(plant.getName().equals("redchilli")){
				Redchilli redchilli = new Redchilli(plant.getRow(),plant.getColumn(), root2);
				redchilli.setHealth(plant.getHealth());
				splant.add(redchilli);
			}
		}
		for(resumezombie zombie :game.getListzombies()){
			if(zombie.getPower()==5){
				NormalZombie normalZombie = new NormalZombie(zombie.getRow(),zombie.getColumn(), root2);
				normalZombie.setHealth(zombie.getHealth());
				szombie.add(normalZombie);
			}
			if(zombie.getPower()==6){
				HeadpieceZombie strongZombie = new HeadpieceZombie(zombie.getRow(),zombie.getColumn(), root2);
				strongZombie.setHealth(zombie.getHealth());
				szombie.add(strongZombie);
			}
			if(zombie.getPower()==8){
				Flagzombie flagzombie = new Flagzombie(zombie.getRow(),zombie.getColumn(), root2);
				flagzombie.setHealth(zombie.getHealth());
				szombie.add(flagzombie);
			}
			if(zombie.getPower()==7){
				Bucketzombie bucketzombie = new Bucketzombie(zombie.getRow(),zombie.getColumn(), root2);
				bucketzombie.setHealth(zombie.getHealth());
				szombie.add(bucketzombie);
			}
		}
		for(resumelawnmower rlawnmower : game.getListlawnmower()){
			int column = 0;
			if(rlawnmower.isLawnmowermoved()){
				column = rlawnmower.getColumn();
			}else{
				column = 3;
			}
			Lawnmower slawnmower = new Lawnmower(rlawnmower.getRow(),column, root2);
			slawnmower.sethaslawnmower(rlawnmower.isLawnmowermoved());
			slawnmowers.add(slawnmower);
		}
		player.setlistplants(splant);
		player.setlistlawnmowers(slawnmowers);
		
		   StackPane s1 = new StackPane();
	        Image peashooter = new Image("file:C:/Users/Sandeep/Desktop/IMAGES/plants/peashooter.gif");
	        ImageView peashooter1 = new  ImageView(peashooter);
	        s1.getChildren().add(peashooter1);
	        s1.setTranslateX(110+60);
	        s1.setTranslateY(15);
	        
	        StackPane s2 = null;
	        Image sunflower = null;
	        ImageView sunflower1 = null;
	        StackPane s3 = null;
	        Image wallnut = null;
	        ImageView wallnut1 = null;
	        StackPane s4 = null;
	        Image cherrybomb = null;
	        ImageView cherrybomb1 = null;
	        StackPane s5 = null;
	        Image redchilli = null;
	        ImageView redchilli1 = null;
	        
	        if(game.getLevel()>=3){
	        	s3 = new StackPane();
	        	wallnut = new Image("file:C:/Users/Sandeep/Desktop/IMAGES/wallnut.png");
	        	wallnut1 = new  ImageView(wallnut);
	        	s3.getChildren().add(wallnut1);
	        	s3.setTranslateX(270+60);
	        	s3.setTranslateY(15);
	        	s3.setId("wallnut");
	        	root2.getChildren().add(s3);
	        }
	        if(game.getLevel()>=4){
	        	s4 = new StackPane();
	        	cherrybomb = new Image("file:C:/Users/Sandeep/Desktop/IMAGES/cherrybomb.png");
	        	cherrybomb1 = new  ImageView(cherrybomb);
	        	s4.getChildren().add(cherrybomb1);
	        	s4.setTranslateX(365+60);
	        	s4.setTranslateY(15);
	        	s4.setId("cherrybomb");
	        	root2.getChildren().add(s4);
	        }
	        if(game.getLevel()>=5){
	        	s5 = new StackPane();
	        	redchilli = new Image("file:C:/Users/Sandeep/Desktop/IMAGES/plants/redchilli.png");
	        	redchilli1 = new  ImageView(redchilli);
	        	s5.getChildren().add(redchilli1);
	        	s5.setTranslateX(365+105+60);
	        	s5.setTranslateY(15);
	        	s5.setId("redchilli");
	        	root2.getChildren().add(s5);
	        }
	        if(game.getLevel()>=2){
	        	s2 = new StackPane();
	        	sunflower = new Image("file:C:/Users/Sandeep/Desktop/IMAGES/plants/sunflower.gif");
	        	sunflower1 = new  ImageView(sunflower);
	        	s2.getChildren().add(sunflower1);
	        	s2.setTranslateX(195+60);
	        	s2.setTranslateY(15);
	        	s2.setId("sunflower");
	        	root2.getChildren().add(s2);
	        }
	        s1.setId("peashooter");
	        root2.getChildren().add(s1);
	     
	        Enemy enemy = new Enemy(root2,0);
	        enemy.setlistzombies(szombie);
			GameController gamecontroller = new GameController(game.getLevel(), player, enemy, stage);
			gamecontroller.initialize();
		     sun.setFont(new Font("Arial",25));
		     sun.setTextFill(Color.BLACK);
		     root2.getChildren().add(sun);
		     sun.setTranslateX(70);
		     sun.setTranslateY(75);
	     
	     PlantDragController spdc1 = new PlantDragController(s1, peashooter);
	     PlantDragController spdc2 = null;
	     PlantDragController spdc3 = null;
	     PlantDragController spdc4 = null;
	     PlantDragController spdc5 = null;
	     if(game.getLevel()>=2){
	    	 spdc2 = new PlantDragController(s2, sunflower);
	     }
	     if(game.getLevel()>=3){
	    	 spdc3 = new PlantDragController(s3, wallnut);
	     }
	     if(game.getLevel()>=4){
	    	 spdc4 = new PlantDragController(s4, cherrybomb);
	     }
	     if(game.getLevel()>=5){
	    	 spdc5 = new PlantDragController(s5, redchilli);
	     }
	     PlantDragOverController spdoc = new PlantDragOverController();
	     PlantDragDropController spddc = new PlantDragDropController(root2, player);
	     SunController sc = new SunController(player,root2,sun);
	 
	     s1.setOnDragDetected(spdc1);
	     if(game.getLevel()>=2){
	    	 s2.setOnDragDetected(spdc2);
	     }
	     if(game.getLevel()>=3){
	    	 s3.setOnDragDetected(spdc3);
	     }
	     if(game.getLevel()>=4){
	    	 s4.setOnDragDetected(spdc4);
	     }
	     if(game.getLevel()>=5){
	    	 s5.setOnDragDetected(spdc5);
	     }
	    scene.setOnDragOver(spdoc);
	    scene.setOnDragDropped(spddc);
		scene.setOnMouseClicked(sc);

		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		initStage = stage;
		Music.play();
		stage.show();
	}
	public Stage getInitiateStage(){
		return initStage;
	}
	public static void main(String[] args) {
		launch(args);
	}
}
