package pzm;

import java.io.IOException;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Screen2 extends Application{
	static Stage initStage = new Stage();
	static int level = 1;
	static int score = 0;
	
	@Override
	public void start(Stage stage) throws Exception {
		AnchorPane root1 = FXMLLoader.load(getClass().getResource("Level1.fxml"));
		Text text = new Text("LEVEL-"+level);
		text.setX(250);
		text.setY(300);
		text.setFont(Font.font("Verdana", 90));
        text.setId("fancytext");
        root1.getChildren().add(text);
		Scene scene = new Scene(root1);
		stage.setScene(scene);
		initStage = stage;
		scene.getStylesheets().add(getClass().getResource("welcome.css").toExternalForm());
		Music.stop();
		stage.show()	;
	}
	public Stage getInitiateStage(){
		return initStage;
	}
	@FXML
    void continuelevel1(ActionEvent event) throws IOException {
		Screen3 pgame = new Screen3();
		try{
			pgame.start(pgame.getInitiateStage());
		}catch(Exception e){ }
		initStage.close();
    }
	@FXML
    void exit(ActionEvent event) {
		Music.stop();
		System.exit(0);
	}
	public static void main(String[] args) {
		launch(args);
	}
}
