package pzm;

import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;

public abstract class Character {
	protected int row;
	protected int column;
	protected int health = 20000;
	protected int power = 100;
	protected StackPane s = new StackPane();
	protected  AnchorPane root;
	protected Player player;
	protected double imageY;
	protected double imageX;
    
    public abstract void setPosition(int x, int y);
    
    public abstract int getHealth();
   
    public abstract void setHealth(int health);
    
    public abstract int getPower();
    
    public abstract void setPower(int power);
  
    public abstract void step();

    public abstract void removeImage();

    public abstract int getRow();

    public abstract int getColumn();
    
}
