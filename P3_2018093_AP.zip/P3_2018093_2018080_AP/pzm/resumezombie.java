package pzm;

import java.io.Serializable;

public class resumezombie implements Serializable{
	private int row;
    private int column;
    private int realcolumn;
    private int health;
    private int power;
    
    public int getRealcolumn() {
		return realcolumn;
	}
	public void setRealcolumn(int realcolumn) {
		this.realcolumn = realcolumn;
	}
    
	public int getRow() {
		return row;
	}
	public void setRow(int row) {
		this.row = row;
	}
	public int getColumn() {
		return column;
	}
	public void setColumn(int column) {
		this.column = column;
	}
	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		this.health = health;
	}
	public int getPower() {
		return power;
	}
	public void setPower(int power) {
		this.power = power;
	}
    
}
