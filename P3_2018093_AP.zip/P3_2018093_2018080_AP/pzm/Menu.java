package pzm;

import java.io.IOException;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Menu extends Application{
	
	static Stage initStage = new Stage();
	static int incrementor = 1;
		public void start(Stage primaryStage) throws Exception {
			Parent root = FXMLLoader.load(getClass().getResource("menu.fxml"));
			primaryStage.setTitle("MENU");
			Scene scene = new Scene(root,550,300); 
			scene.getStylesheets().add(getClass().getResource("welcome2.css").toExternalForm());
			primaryStage.setScene(scene);
			initStage = primaryStage;
			primaryStage.show();
		}
		public void save() throws IOException{
			Serializedeserialize.setGame(Screen3.game);
			Serializedeserialize.filename = Screen1.username+incrementor+".txt";
			incrementor++;
			Serializedeserialize.serialize();	
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("MESSAGE!");
			alert.setHeaderText("Saved Successfully....");
			alert.showAndWait();
			initStage.close();
			GameController.time = 1;
		}
		public void restart(){
			initStage.close();
			Screen3.initStage.close();
			Platform.runLater(() -> {
				try {
					new Screen3().start(new Stage());
				} catch (Exception e) {
					e.printStackTrace();
				}
			});
			GameController.time = 1;
		}
		@FXML
	    void exit(ActionEvent event) {
			initStage.close();
			GameController.time = 1;
		}
		@FXML
	    void exit1(ActionEvent event) throws IOException, ClassNotFoundException {
			Serializedeserialize.deserializescoreboard();
			Serializedeserialize.serializescore();
			Music.stop();
			initStage.close();
			System.exit(0);
		}
		public Stage getInitiateStage(){
			return initStage;
		}
	public static void main(String[] args) {
		launch(args);
	}

}
