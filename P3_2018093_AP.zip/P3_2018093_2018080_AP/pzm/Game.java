package pzm;

import java.io.Serializable;
import java.util.ArrayList;

import javafx.scene.control.Label;

public class Game implements Serializable {
	private int level;
	private int sun;
	private ArrayList<resumeplants> listPlants;
	private ArrayList<resumezombie> listzombies;
	private ArrayList<resumelawnmower> listlawnmower;
	
	public ArrayList<resumelawnmower> getListlawnmower() {
		return listlawnmower;
	}

	public void setListlawnmower(ArrayList<resumelawnmower> listlawnmower) {
		this.listlawnmower = listlawnmower;
	}

	public Game(){ }

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getSun() {
		return sun;
	}

	public void setSun(int sun) {
		this.sun = sun;
	}

	public ArrayList<resumeplants> getListPlants() {
		return listPlants;
	}

	public void setListPlants(ArrayList<resumeplants> listPlants) {
		this.listPlants = listPlants;
	}

	public ArrayList<resumezombie> getListzombies() {
		return listzombies;
	}

	public void setListzombies(ArrayList<resumezombie> listzombies) {
		this.listzombies = listzombies;
	}

}
