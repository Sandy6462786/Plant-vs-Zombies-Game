package pzm;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;

public class Sunflower extends Plant {
	
	private Image star;
    private ImageView starView;
    private boolean hasStar = false;
    private int shoot_count3 = 5000;
    private StackPane s2 = new StackPane();
    private boolean hasbuy = true;
    
    public Sunflower(int row, int column, AnchorPane root, Player player){
        this.star= new Image("file:C:/Users/Sandeep/Desktop/IMAGES/sun.png");
        this.starView = new ImageView(star);
        this.s2.getChildren().add(starView);
        this.player = player;
        this.row = row;
        this.column = column;
        this.plant = new Image("file:C:/Users/Sandeep/Desktop/IMAGES/plants/sunflower.gif");
        this.plantView = new  ImageView(plant);
        s.getChildren().add(plantView);
        this.root = root;
        root.getChildren().add(s);
        s.setTranslateY((int) (135+(row-1)*110+55)-40);
        s.setTranslateX((int) (60+(column-1)*80+40)-40);
    }

    public void removeImage(){
        this.s.getChildren().remove(this.plantView);
        this.root.getChildren().remove(this.s);
        this.s2.getChildren().remove(this.starView);
        this.root.getChildren().remove(this.s2);
    }

    public void removeStar(){
        this.s2.getChildren().remove(this.starView);
        this.root.getChildren().remove(this.s2);
    }

    public int getRow(){
        return this.row;
    }

    public int getColumn(){
        return this.column;
    }

    public void setPosition(int row, int column){
        this.row = row;
        this.column = column;
    }

    public int getHealth(){
        return health;
    }

    public void setHealth(int health){
        this.health = health;
    }

    public int getPower(){
        return power;
    }

    public void setPower(int power){
        this.power = power;
    }

    public int getPrice(){
        return 50;
    }

    public void setPrice(int price){
        this.price = price;
    }

    public String getName(){
        return "sunflower";
    }

	@Override
    public void step(){
        if (this.shoot_count == 5000){
            StackPane s2 = new StackPane();
            s2.getChildren().add(this.starView);
            s2.setTranslateY((int) (135+(row-1)*110+55)-40+1);
            s2.setTranslateX((int) (60+(column-1)*80+40)-40-20);
            root.getChildren().add(s2);
            this.s2 = s2;
            this.shoot_count = 0;
            hasStar = true;
        } else {
            this.shoot_count ++;
        }
    }
	public void setshoot_count3tozero(){
		shoot_count3 = 0;
	}
	public void step3(){
        if (shoot_count3 == 5000){
            hasbuy = true;
        } else {
            shoot_count3 ++;
        }
	}
	public void sethasbuy(boolean bool){
    	hasbuy = bool;
    }
    public boolean gethasbuy(){
    	return hasbuy;
    }
	 public boolean isHasStar(){
	        return hasStar;
	    }
	 public void setHasStar(boolean bool){
	        hasStar = bool;
	    }
}
