package pzm;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Screen4  extends Application{
	static Stage initStage = new Stage();
	int level = Screen2.level;
	@Override
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("winwallnut.fxml"));
		primaryStage.setTitle("PLANT VS ZOMBIES");
		Scene scene = new Scene(root); 
		scene.getStylesheets().add(getClass().getResource("welcome.css").toExternalForm());
		
		StackPane s = null;
    	Image plant = null;
    	ImageView plantView = null;
    	Text text = null;
		
    	if(level==1){
    		s = new StackPane();
    		text = new Text("You win sunflower");
    		plant = new Image("file:C:/Users/Sandeep/Desktop/IMAGES/plants/sunflower.gif");
    	}
    	if(level==2){
    		s = new StackPane();
    		text = new Text("You win wallnut");
    		plant = new Image("file:C:/Users/Sandeep/Desktop/IMAGES/wallnut.png");
    	}
    	if(level==3){
    		s = new StackPane();
    		text = new Text("You win cherrybomb");
    		plant = new Image("file:C:/Users/Sandeep/Desktop/IMAGES/cherrybomb.png");
    	}
    	if(level==4){
    		s = new StackPane();
    		text = new Text("You win Redchilli");
    		plant = new Image("file:C:/Users/Sandeep/Desktop/IMAGES/plants/redchilli.png");
    	}
    	plantView = new  ImageView(plant);
    	s.getChildren().add(plantView);
    	s.setTranslateX(450);
    	s.setTranslateY(150);
    	s.setScaleX(3);
    	s.setScaleY(3);
    	root.getChildren().add(s);
    	
		text.setX(170);
		text.setY(360);
		text.setId("fancytext");
        root.getChildren().add(text);
		
		primaryStage.setScene(scene);
		initStage = primaryStage;
		primaryStage.show();
	}
	public Stage getInitiateStage(){
		return initStage;
	}
	@FXML
    void playgame(ActionEvent event) throws Exception {
			Screen2 pgame = new Screen2();
			Screen2.level++;
			try{
				pgame.start(pgame.getInitiateStage());
			}catch(Exception e){ }
			initStage.close();
	}
	@FXML
    void exit(ActionEvent event) {
		System.exit(0);
	}
	public static void main(String[] args) {
		launch(args);
	}
}
