package pzm;

import java.util.ArrayList;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CreateUser extends Application{
	
	static Stage initStage = new Stage();
	@FXML
	private TextField takename;
		public void start(Stage primaryStage) throws Exception {
			Parent root = FXMLLoader.load(getClass().getResource("createprofile.fxml"));
			primaryStage.setTitle("USER ADDITION");
			Scene scene = new Scene(root,550,300); 
			scene.getStylesheets().add(getClass().getResource("welcome2.css").toExternalForm());
			primaryStage.setScene(scene);
			initStage = primaryStage;
			primaryStage.show();
		}
		public void adduser(){
			String username = takename.getText();
			if(username.equals("")){
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ALERT!");
				alert.setHeaderText("Please enter your name..");
				alert.showAndWait();
			}else{
			int q = 0;
			for(String s : Screen1.users){
				if(username.equals(s)){
					q = 1;
				}
			}
			if(q==0){
				Screen1.users.add(username);
				Screen1.username = username;
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ALERT!");
				alert.setHeaderText("User added successfully...");
				alert.showAndWait();
				initStage.close();
			}
			}
			takename.setText("");
		}
		@FXML
	    void exit(ActionEvent event) {
			initStage.close();
		}
		public Stage getInitiateStage(){
			return initStage;
		}
	public static void main(String[] args) {
		launch(args);
	}

}
