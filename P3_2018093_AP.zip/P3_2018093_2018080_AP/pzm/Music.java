package pzm;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

import sun.audio.*;


public class Music {
	static InputStream music;
	static AudioStream audio;
	
	public static void play() throws IOException{
		music  = new FileInputStream("A:/sa/02 Crazy Dave (Intro Theme).wav");
		audio = new AudioStream(music);
		AudioPlayer.player.start(audio);
	}
	public static void stop(){
		if(audio!=null){
			AudioPlayer.player.stop(audio);
		}
	}
}
